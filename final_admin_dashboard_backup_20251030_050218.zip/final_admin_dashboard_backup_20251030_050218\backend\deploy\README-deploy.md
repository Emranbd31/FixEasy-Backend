﻿## FixEasy Backend Deployment Guide
- Ubuntu 22+ server with Docker and Docker Compose installed
- Ports 22, 80, 443, and 8000 open
- .env file at /srv/backend/.env
