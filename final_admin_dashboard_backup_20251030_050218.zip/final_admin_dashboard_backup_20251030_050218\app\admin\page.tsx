"use client";

export default function AdminPlaceholderPage() {
  return (
    <main>
      <h1>Admin Page Placeholder</h1>
    </main>
  );
}
